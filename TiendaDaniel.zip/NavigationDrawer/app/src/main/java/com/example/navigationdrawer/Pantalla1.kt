package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla1() {
    LazyColumn() {
        item {
            Text(text = "SILLA",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Image(
                painter = painterResource(id = R.drawable.silla),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top = 20.dp)
            )
            Text(text = "Una silla cómoda, diseñada para brindar máximo confort, con acolchado suave, respaldo ergonómico y estructura resistente, ideal para largos periodos de uso sin sacrificar comodidad.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "MESA",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.mesa),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top = 20.dp)
            )
            Text(text = "Una mesa pequeña de madera, compacta y elegante, con acabado natural, perfecta para espacios reducidos o como elemento decorativo funcional.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "PUFF",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.puff),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top = 20.dp)
            )
            Text(text = "Un puff sumamente cómodo, con relleno mullido y tapizado suave, ideal para relajarse en casa y añadir un toque acogedor a cualquier espacio.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
        }
    }
}