package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla2() {
    LazyColumn() {
        item {
            Text(text = "MÓVIL",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.movil),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Un iPhone, elegante dispositivo móvil de Apple, combina diseño refinado con tecnología avanzada, ofreciendo una experiencia intuitiva, potente y conectada.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "TABLET",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.tablet),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Una tablet, dispositivo portátil con pantalla táctil, versátil para navegación, entretenimiento y productividad, en un formato compacto y ligero.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "TELE",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.tele),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Una tele, pantalla electrónica que ofrece imágenes y sonido, proporcionando entretenimiento visual en el hogar.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
        }
    }
}