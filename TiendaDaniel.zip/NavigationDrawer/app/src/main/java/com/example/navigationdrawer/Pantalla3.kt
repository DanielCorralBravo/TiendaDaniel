package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla3() {
    LazyColumn() {
        item {
            Text(text = "ABRIGO",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.abrigo),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Un abrigo The North Face, prenda de alta calidad y diseño resistente, con tecnología de aislamiento térmico, ideal para condiciones climáticas adversas y estilo outdoor.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "SUDADERA",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.sudadera),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Una sudadera Lacoste, prenda deportiva de alta gama, con el icónico cocodrilo bordado, estilo elegante y comodidad para uso casual o activo.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "ZAPATILLAS",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.zapatillas),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Una zapatilla Nike, calzado deportivo reconocido, con diseño moderno, tecnología de amortiguación y versatilidad para actividades físicas o estilo urbano.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
        }
    }
}