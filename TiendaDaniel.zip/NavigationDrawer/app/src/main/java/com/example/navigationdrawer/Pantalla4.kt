package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla4() {
    LazyColumn() {
        item {
            Text(text = "NEVERA",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.nevera),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "MICROHONDAS",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Text(text = "Una nevera de última tecnología, con características avanzadas como control digital, eficiencia energética, sistema de enfriamiento inteligente y diseño funcional para una conservación óptima de alimentos.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Image(
                painter = painterResource(id = R.drawable.microhondas),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp, start=10.dp)
            )
            Text(text = "Un microondas, electrodoméstico de cocina que utiliza ondas para calentar alimentos de manera rápida y eficiente, proporcionando conveniencia en el calentamiento y descongelamiento de comidas.",
                modifier = Modifier.padding(top=10.dp, start=30.dp)
                )
            Text(text = "LAVADORA",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.lavadora),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Una lavadora, electrodoméstico esencial para la ropa, que utiliza agua y detergentes para limpiar y refrescar la ropa de manera automática, simplificando el proceso de lavado.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
        }
    }
}