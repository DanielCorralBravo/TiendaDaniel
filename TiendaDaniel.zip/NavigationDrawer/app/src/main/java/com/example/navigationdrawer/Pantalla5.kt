package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla5() {
    LazyColumn() {
        item {
            Text(text = "BAKUGAN",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.bakugan),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Los Bakugan son juguetes de colección y juego estratégico que se transforman desde una esfera cerrada en criaturas en miniatura cuando se lanzan sobre tarjetas metálicas. Cada uno tiene atributos y habilidades únicas para enfrentarse en batallas.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "GORMITI",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.gormiti),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp, start=20.dp)
            )
            Text(text = "Los Gormiti son figuras coleccionables y personajes de un mundo de fantasía, representando elementos naturales como tierra, aire, agua y fuego. Estas figuras son parte de un juego que involucra estrategia y batallas en un universo ficticio.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "PEONZA",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.peonza),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp, start=20.dp)
            )
            Text(text = "Una peonza es un juguete clásico que consiste en un trompo que, al girar sobre una punta, despliega movimientos y patrones interesantes, ofreciendo diversión y entretenimiento.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
        }
    }
}