package com.example.navigationdrawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Pantalla6() {
    LazyColumn() {
        item {
            Text(text = "CUADRO",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.cuadro),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp)
            )
            Text(text = "Un cuadro de decoración es una pieza artística destinada a embellecer un espacio interior, con motivos estéticos y colores que complementan la decoración del entorno, aportando un toque visual y personal al ambiente.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "ALFOMBRA",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.alfombra),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp, start=20.dp)
            )
            Text(text = "Una alfombra es una pieza textil que se coloca en el suelo para proporcionar confort, aislamiento térmico y decoración en espacios interiores, con diferentes diseños, colores y texturas.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
            Text(text = "PLANTAS",
                fontSize = 20.sp,
                modifier = Modifier.padding(top=10.dp, start=20.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.plantas),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(180.dp)
                    .padding(top= 20.dp, start=20.dp)
            )
            Text(text = "Unas macetas con plantas de decoración son elementos que combinan la belleza de las plantas con el diseño estético de las macetas, aportando frescura y estilo a espacios interiores o exteriores.",
                modifier = Modifier.padding(top=10.dp, start=20.dp)
                )
        }
    }
}